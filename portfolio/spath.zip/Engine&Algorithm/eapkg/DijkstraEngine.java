package eapkg;
import graphpkg.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.PriorityQueue;

/**
 * Computes the shortest path algorithm on a graph of the type {@link graphpkg.Map} giving a
 * starting and ending node and the type of the weight desired. Since it uses a PriorityQueue
 * to store the graph information, it improves the running time of the extractMin method, causing
 * the algorithm to run on O(|E|+|V|log|V|) instead of the O(|V|^2+|E|) that would be needed with
 * a regular linked list or array (extractMin would need to iterate through all the nodes). The
 * only downcome to this structure is the reSort method, which has an expensive running time and
 * needs to be called several times. The algorithm used is implemented as follows:
 * 
 * <p>
 * function Dijkstra(Graph, source):
 *     for each vertex v in Graph:           // Initializations
 *         dist[v] := infinity               // Unknown distance function from source to v
 *         previous[v] := undefined
 *     dist[source] := 0                     // Distance from source to source
 *     Q := copy(Graph)                      // All nodes in the graph are unoptimized - thus are in Q
 *     while Q is not empty:                 // The main loop
 *         u := extract_min(Q)               // Remove and return best vertex from nodes in two given nodes
 *                                           // we would use a path finding algorithm on the new graph, such as depth-first search.
 *         for each neighbor v of u:         // where v has not yet been removed from Q.
 *             alt := dist[u] + length(u, v)
 *             if alt < dist[v]              // Relax (u,v)
 *                 dist[v] := alt
 *                 previous[v] := u
 *      return previous[]
 * 
 * If we are only interested in a shortest path between vertices source and target, we can terminate the search at line 9 if u = target.
 * Now we can read the shortest path from source to target by iteration:
 *
 * S := empty sequence
 * u := target
 * while defined previous[u]
 *     insert u at the beginning of S
 *     u := previous[u]
 * </p>
 * 
 * The shortest path is returned in the correct order with the node indexes ordered in an ArrayList.
 * 
 * @author Jo�o Xavier / ei06116
 * @author Jo�o Ribeiro / ei06019
 * @version 1.337
 * @see <a href="http://en.wikipedia.org/wiki/Dijkstra_algorithm">Details on the Dijkstra Algorithm used</a>
 */
public class DijkstraEngine
{
	/**
	 * Runs the Dijkstra algorithm on the graph. Initializes two arrays, <code>previous</code>,
	 * which saves the index of the previous node, and <code>dist</code>, which keeps the partial
	 * weight of each node. Then it copies node information to a PriorityQueue and it proceeds to
	 * the main while loop which will end either when there are no nodes remaining on the queue or
	 * the target node has been reached. Extracts the node with least partial weight that has yet
	 * to be processed, and does a relaxNeighbour operation over all the edges of the node, which
	 * is a update of the partial weight values in <code>dist</code> and a resorting of an element
	 * of the <code>PriorityQueue<Node>Q</code>. When the program breaks out of the loop, the shortest
	 * path can be retrieved using the <code>previous</code> array in the reverse order, so it calls
	 * Reverse from the library Collections and returns the correcly ordered shortest path.
	 * 
	 * @param map the graph
	 * @param source the starting node
	 * @param target the ending node
	 * @param isDistance true if distance is weight, false if duration is weight
	 * 
	 * @return a ArrayList<Integer> containing the shortest path information
	 */
	public ArrayList<Integer> Dijkstra(Map map, int source, int target, boolean isDistance)
	{
		Node[] cities = map.getCities();
		int[] previous = new int[Global.MAX_CITIES+1];
		initializeDist(source);
		
		PriorityQueue<Node> Q = copy(cities);
		
		while (!Q.isEmpty())
		{	
			int u = extractMin(Q);
			
			if (u == target)
				break;
			
			ArrayList<Route> destinations = cities[u].getDestinations();	
			
			for (Route r: destinations)
			{
				int v = r.getDestination();
				int alt = Global.dist[u] + r.getWeight(isDistance);
				int distv = Global.dist[v];
				
				if (alt < distv)
				{
					Global.dist[v] = alt;
					previous[v] = u;
					reSort(Q, cities[v]);
				}
			}
		}
		
		ArrayList<Integer> shortestPath = new ArrayList<Integer>();
		for (int u = target; u != 0; u = previous[u])
			shortestPath.add(u);
		Collections.reverse(shortestPath);
		
		return shortestPath;
	}
	
	/**
	 * Initializes the dist array to half of the Integer.MAX_VALUE (so it doesn't overflow)
	 * except the source index, which is initialized to 0.
	 * 
	 * @param source the starting node
	 */
	private void initializeDist(int source)
	{
		Global.dist = new int[Global.MAX_CITIES+1];
		int maxValue = Integer.MAX_VALUE >> 1;
		
		for (int v = 1; v <= Global.MAX_CITIES; v++)
			Global.dist[v] = maxValue;
		Global.dist[source] = 0;
	}
	
	/**
	 * Copies the node information from the array cities into a priority queue, which is
	 * returned.
	 * 
	 * @param cities all the nodes that the graph contains
	 * 
	 * @return a PriorityQueue<Node> already initialized with all the nodes from the graph
	 */
	private PriorityQueue<Node> copy(Node[] cities)
	{
		PriorityQueue<Node> Q = new PriorityQueue<Node>(Global.MAX_CITIES);
		
		for (int v = 1; v <= Global.MAX_CITIES; v++)
			Q.add(cities[v]);	
			
		return Q;
	}
	
	/**
	 * Called when the information in the queue is updated, removes and adds the Node n to the
	 * PriorityQueue<Node> Q in order to put it on the right place again.
	 * 
	 * @param Q priority queue with all the nodes
	 * @param n the node that needs to be replaced
	 */
	private void reSort(PriorityQueue<Node> Q, Node n)
	{
		Q.remove(n);
		Q.add(n);
	}
	
	/**
	 * Removes the head element from the queue and retrieves its unique ID.
	 * 
	 * @param Q priority queue with all the nodes
	 * 
	 * @return the index of the node with lowest partial distance
	 */
	private int extractMin(PriorityQueue<Node> Q)
	{	
		return (Q.poll()).getNodeID();
	}
}
