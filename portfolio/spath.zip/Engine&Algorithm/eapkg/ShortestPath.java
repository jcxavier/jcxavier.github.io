package eapkg;
import guipkg.ShortestPathGUI;
import java.io.*;
import javax.swing.*;

/**
 * Wields the main method, which runs the Shortest Path program in a GUI (Graphical
 * User Interface).
 * 
 * @author Jo�o Xavier / ei06116
 * @author Jo�o Ribeiro / ei06019
 * @version 1.337
 */
public class ShortestPath
{
	/**
	 * Executes the graphical user interface.
	 * 
	 * @param f the frame to execute
	 * @param width fixed width of the frame
	 * @param height fixed height of the frame
	 */
	private static void run(final JFrame f, final int width, final int height)
	{
		SwingUtilities.invokeLater(new Runnable()
		{
			public void run()
			{
				f.setTitle("Shortest Path");
				f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				f.setSize(width, height);
				f.setVisible(true);
			}
		});
	}
	
	/**
	 * Runs the Shortest Path program with the USA-NY files and in a 850x750 window.
	 * 
	 * @param args arguments called with the command line (no usage on this program)
	 */
	public static void main(String[] args)
	{
		//String coFile = "TEST-road-d.XPTO.co", dgrFile = "TEST-road-d.XPTO.gr", tgrFile = "TEST-road-t.XPTO.gr";
		String coFile = "USA-road-d.NY.co", dgrFile = "USA-road-d.NY.gr", tgrFile = "USA-road-t.NY.gr";
		try {
			new BufferedLoader(coFile, dgrFile, tgrFile); }
		catch (FileNotFoundException fnfe) {
			System.out.println("file not found");}
		catch (IOException ioe) {
			System.out.println("i/o error");}
		
		ShortestPathGUI spGUI = new ShortestPathGUI();
		run(spGUI, 850, 750);
	}
}