package eapkg;
import graphpkg.Map;

/**
 * Provides global access to some variables which are used in multiple places.
 * 
 * @author Jo�o Xavier / ei06116
 * @author Jo�o Ribeiro / ei06019
 * @version 1.337
 */
public class Global
{
	/**
	 * Array of integers that contains the distances from
	 * the starting node in the algorithm to the correspondent node.
	 */
	public static int[] dist;
	/**
	 * Constant that defines the total number of cities being processed (number of
	 * nodes)
	 */
	public static int MAX_CITIES;
	/**
	 * The graph (object of the class {@link graphpkg.Map}).
	 */
	public static Map map;
}
