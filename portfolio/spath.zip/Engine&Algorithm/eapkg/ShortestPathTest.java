package eapkg;
import java.util.ArrayList;
import java.util.Arrays;
import java.io.*;
import junit.framework.TestCase;

/**
 * Provides all the test cases used during the developing of the ShortestPath program.
 * 
 * @author Jo�o Xavier / ei06116
 * @author Jo�o Ribeiro / ei06019
 * @version 1.337
 */
public class ShortestPathTest extends TestCase
{
	/**
	 * Tests the FileNotFoundException by passing files that don't exist as parameters to
	 * the parser.
	 */
	public void testReadFileException()
	{
		String co_file = "NO-file-d.FOUND.co", dgr_file = "NO-file-d.FOUND.gr", tgr_file = "NO-file-t.FOUND.gr";
		
		try { new BufferedLoader(co_file, dgr_file, tgr_file); fail(); }
		catch (FileNotFoundException fnfe) { System.out.println("file not found"); }
		catch (Exception e) { fail(); }
	}
	
	/**
	 * Reads a small test case file with a time limit of 20 miliseconds.
	 */
	public void testReadSmallFile()
	{
		String co_file = "TEST-road-d.XPTO.co", dgr_file = "TEST-road-d.XPTO.gr", tgr_file = "TEST-road-t.XPTO.gr";
		long maxTime = 20, init = System.currentTimeMillis();
		try { new BufferedLoader(co_file, dgr_file, tgr_file); }
		catch (FileNotFoundException fnfe) { fail(); }
		catch (IOException ioe) { fail(); }
		long end = System.currentTimeMillis(), z = end-init;
		
		System.out.println("small test case processing time: " + (z/1000.0) + " s");
		
		if (z > maxTime)
			System.out.println("expected time: " + (maxTime/1000.0) + " s");
		
		assertTrue(z <= maxTime);
	}
	
	/**
	 * Verifies that the small test case file was read correctly.
	 */
	public void testReadSmallFileCorrectly()
	{
		assertEquals(Global.MAX_CITIES, 11);
		assertEquals(Global.map.getCities()[3].getCoordY(), 8);
	}
	
	/**
	 * Applies the shortest path algorithm using distance as weight on the small test case
	 * file to test its correction. It has a 20 milisecond time limit to return an answer.
	 */
	public void testDijkstraSmall1()
	{
		DijkstraEngine engine = new DijkstraEngine();
		long maxTime = 20, init = System.currentTimeMillis();
		ArrayList<Integer> shortestPath = engine.Dijkstra(Global.map, 1, 3, true);
		long end = System.currentTimeMillis(), z = end-init;
		Integer[] solution = {1, 6, 2, 5, 4, 3};
		
		System.out.println("small test case 1 algorithm time: " + (z/1000.0) + " s");
		
		if (z > maxTime)
			System.out.println("expected time: " + (maxTime/1000.0) + " s");
		
		assertTrue(z <= maxTime);
		assertTrue(Arrays.deepEquals(solution, shortestPath.toArray(new Integer[solution.length])));			
	}
	
	/**
	 * Applies the shortest path algorithm using duration as weight on the small test case
	 * file to test its correction. It has a 20 milisecond time limit to return an answer.
	 */
	public void testDijkstraSmall2()
	{
		DijkstraEngine engine = new DijkstraEngine();
		long maxTime = 20, init = System.currentTimeMillis();
		ArrayList<Integer> shortestPath = engine.Dijkstra(Global.map, 1, 10, false);
		long end = System.currentTimeMillis(), z = end-init;
		Integer[] solution = {1, 6, 8, 10};
		
		System.out.println("small test case 2 algorithm time: " + (z/1000.0) + " s");
	
		if (z > maxTime)
			System.out.println("expected time: " + (maxTime/1000.0) + " s");
		
		assertTrue(z <= maxTime);
		assertTrue(Arrays.deepEquals(solution, shortestPath.toArray(new Integer[solution.length])));			
	}
	
	/**
	 * Tests the reading performance by loading a medium sized test file. Runs with a
	 * time limit of 10 seconds.
	 */
	public void testReadMediumFile()
	{
		String co_file = "USA-road-d.NY.co", dgr_file = "USA-road-d.NY.gr", tgr_file = "USA-road-t.NY.gr";
		long maxTime = 10000, init = System.currentTimeMillis();
		try { new BufferedLoader(co_file, dgr_file, tgr_file); }
		catch (FileNotFoundException fnfe) { fail(); }
		catch (IOException ioe) { fail(); }
		long end = System.currentTimeMillis(), z = end-init;
		
		System.out.println("medium test case processing time: " + (z/1000.0) + " s");
		
		if (z > maxTime)
			System.out.println("expected time: " + (maxTime/1000.0) + " s");
		
		assertTrue(z <= maxTime);
	}
	
	/**
	 * Verifies that the medium test case file was read correctly.
	 */
	public void testReadMediumFileCorrectly()
	{
		assertEquals(Global.MAX_CITIES, 264346);
		assertEquals(Global.map.getCities()[221251].getCoordX(), -74175199);
	}
	
	/**
	 * Tests the algorithm performance by applying it to the medium test case file with
	 * a quick example that is required to run in less than 500 miliseconds.
	 */
	public void testDijkstraMedium1()
	{
		DijkstraEngine engine = new DijkstraEngine();
		long maxTime = 500, init = System.currentTimeMillis();
		engine.Dijkstra(Global.map, 1, 5974, true);
		long end = System.currentTimeMillis(), z = end-init;
		
		System.out.println("medium test case 1 algorithm time: " + (z/1000.0) + " s");
		
		if (z > maxTime)
			System.out.println("expected time: " + (maxTime/1000.0) + " s");
		
		assertTrue(z <= maxTime);
	}
	
	/**
	 * Tests the algorithm performance by applying it to the medium test case file with
	 * a slow example that is required to run in less than 150 seconds.
	 */
	public void testDijkstraMedium2()
	{
		DijkstraEngine engine = new DijkstraEngine();
		long maxTime = 150000, init = System.currentTimeMillis();
		engine.Dijkstra(Global.map, 1, 7345, true);
		long end = System.currentTimeMillis(), z = end-init;
		
		System.out.println("medium test case 2 algorithm time: " + (z/1000.0) + " s");
		
		if (z > maxTime)
			System.out.println("expected time: " + (maxTime/1000.0) + " s");
		
		assertTrue(z <= maxTime);
	}
}
