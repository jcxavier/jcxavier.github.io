package eapkg;
import graphpkg.*;
import java.io.*;
import java.util.Scanner;

/**
 * Parses the graph information from files of the type *.co and *.gr and initializates the
 * program's data structure with them. Uses the class Scanner to process the files to make
 * the parsing easier to implement.
 * 
 * @author Jo�o Xavier / ei06116
 * @author Jo�o Ribeiro / ei06019
 * @version 1.0
 * @deprecated When version 1.337 was released the use of FileLoader was dropped due to
 * 			   taking a long time to read files. Latest version uses {@link eapkg.BufferedLoader}.
 *
 */
public class FileLoader
{
	/**
	 * Constructor of the class FileLoader, takes the three filenames as parameters and
	 * parses them using Scanner. To process the files, the method iterates through the files
	 * until it finds the desired character or integer to proceed. The files containing the 
	 * edges' information are read at the same time to save one whole iteration through the
	 * graph. Updates the global variables <code>MAX_CITIES</code> and <code>map</code>.
	 * 
	 * @param coFile the name of the file that contains the coordinates information
	 * @param dgrFile the name of the file that contains the information of where
	 * 				   each node connects to and the distance (weight)
	 * @param tgrFile the name of the file that contains the information of where
	 * 				   each node connects to and the duration (weight)
	 * 
	 * @throws FileNotFoundException if there is no such file
	 */
	public FileLoader(String coFile, String dgrFile, String tgrFile) throws FileNotFoundException
	{	
		int numCities = 0;
		Global.map = new graphpkg.Map(0);
		
		Scanner co = new Scanner(new BufferedReader(new	FileReader(coFile)));
		
		while(!co.hasNextInt())
			co.next();
		
		numCities = co.nextInt();
		Global.map = new graphpkg.Map(numCities);
		Global.MAX_CITIES = numCities;
		
		while(!co.hasNext("v"))
			co.next();
		
		while(co.hasNext())
		{
			co.next();
			int cityidx = co.nextInt();
			int coordx = co.nextInt(), coordy = co.nextInt();
			City temp = new City(cityidx, coordx, coordy);
			Global.map.addCity(cityidx, temp);
		}
		
		co.close();
		
		Scanner dgr = new Scanner(new BufferedReader(new FileReader(dgrFile)));
		Scanner tgr = new Scanner(new BufferedReader(new FileReader(tgrFile)));
		
		while(!dgr.hasNext("a"))
		{
			dgr.next();
			tgr.next();
		}
		
		while(dgr.hasNext())
		{
			dgr.next(); 						tgr.next();
			int cityidx = dgr.nextInt(); 		tgr.next();
			int destination = dgr.nextInt();	tgr.next();
			int distance = dgr.nextInt();
			int duration = tgr.nextInt();
			Route r = new Route(destination, distance, duration);
			Global.map.addRouteToCity(cityidx, r);
		}
	
		dgr.close();
		tgr.close();
	}
}
