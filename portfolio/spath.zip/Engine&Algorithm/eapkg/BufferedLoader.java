package eapkg;
import graphpkg.*;
import java.io.*;

/**
 * Parses the graph information from files of the type *.co and *.gr and initializates the
 * program's data structure with them. Uses the class BufferedReader to read the files, which
 * proved to have a better performance than the class Scanner reading the files (1/3 of
 * {@link eapkg.FileLoader}), although it isn't as simple.
 * 
 * @author Jo�o Xavier / ei06116
 * @author Jo�o Ribeiro / ei06019
 * @version 1.337
 */
public class BufferedLoader
{
	/**
	 * Takes a file and skips n number of lines in it.
	 * 
	 * @param file where the lines will be skipped
	 * @param n number of lines to be skipped
	 * 
	 * @throws IOException if no more lines to read
	 */
	private void processLines(BufferedReader file, int n) throws IOException
	{
		for (int i = 0; i != n; i++)
			file.readLine();
	}	
	
	/**
	 * Constructor of the class BufferedLoader. Parses three graph files using BufferedReader,
	 * using the split function from the class String to parse the integers from the lines read.
	 * Reads the coordinate file first in order to initialize the graph with the cities, and then the
	 * files containing the edges' weights at the same time, so that the graph ({@link graphpkg.Map}
	 * is only iterated two times (first at .co file and second at .gr files). Updates the global
	 * variables <code>MAX_CITIES</code> and <code>map</code>.
	 * 
	 * @param coFile the name of the file that contains the coordinates information
	 * @param dgrFile the name of the file that contains the information of where
	 * 				   each node connects to and the distance (weight)
	 * @param tgrFile the name of the file that contains the information of where
	 * 				   each node connects to and the duration (weight)
	 * 
	 * @throws FileNotFoundException if there is no such file
	 * @throws IOException if no more lines to read
	 */
	public BufferedLoader(String coFile, String dgrFile, String tgrFile) throws FileNotFoundException, IOException
	{
		int numCities = 0;
		Global.map = new Map(0);
		
		BufferedReader co = new BufferedReader(new FileReader(coFile));
		processLines(co, 4);
		
		numCities = Integer.parseInt(co.readLine().split(" ", 5)[4]);
		Global.map = new Map(numCities);
		Global.MAX_CITIES = numCities;
		
		processLines(co, 2);
		
		for (String line = co.readLine(); line != null; line = co.readLine())
		{
			String[] vars = line.split(" ", 4);
			int cityidx = Integer.parseInt(vars[1]), coordx = Integer.valueOf(vars[2]), coordy = Integer.valueOf(vars[3]);
			City temp = new City(cityidx, coordx, coordy);
			Global.map.addCity(cityidx, temp);
		}
		
		co.close();
		
		BufferedReader dgr = new BufferedReader(new FileReader(dgrFile));
		BufferedReader tgr = new BufferedReader(new FileReader(tgrFile));
		
		processLines(dgr, 7);
		processLines(tgr, 7);
		
		for (String line_dgr = dgr.readLine(), line_tgr = tgr.readLine(); line_dgr != null; line_dgr = dgr.readLine(), line_tgr = tgr.readLine())
		{
			String[] vars = line_dgr.split(" ", 4);
			int cityidx = Integer.parseInt(vars[1]), destination = Integer.parseInt(vars[2]);
			int distance = Integer.parseInt(vars[3]), duration = Integer.parseInt(line_tgr.split(" ", 4)[3]);
			Route r = new Route(destination, distance, duration);
			Global.map.addRouteToCity(cityidx, r);
		}
		
		dgr.close();
		tgr.close();
	}	
}
