package graphpkg;

/**
 * Implementation of a graph data structure. The only information that it contains
 * is an array <code>cities</code> with all the nodes (objects of the class
 * {@link graphpkg.City}), so that retrieving them has running time O(1). The nodes
 * contain edges of the type {@link graphpkg.Route}.
 *
 * @author Jo�o Xavier / ei06116
 * @author Jo�o Ribeiro / ei06019
 * @version 1.337
 */
public class Map
{
	/**
	 * Nodes of the graph.
	 */
	private City[] cities;
		
	/**
	 * Constructor of class Map, initializes the array cities.
	 * 
	 * @param maxCities maximum size of the array cities
	 */
	public Map(int maxCities)
	{
		this.cities = new City[maxCities+1];
	}
	
	/** 
	 * Retrieves the private array cities.
	 * 
	 * @return the private array cities
	 */
	public City[] getCities()
	{
		return cities;
	}
	
	/**
	 * Assigns a City c to the position idx of the array cities.
	 * 
	 * @param idx index of the array position
	 * @param c the City to put into the array
	 */
	public void addCity(int idx, City c)
	{
		cities[idx] = c;
	}
	
	/**
	 * Adds a Route r to the City of position idx in the array cities.
	 * 
	 * @param idx index of the array position
	 * @param r	the route to add to the city
	 */
	public void addRouteToCity(int idx, Route r)
	{
		cities[idx].addRoute(r);
	}
}
