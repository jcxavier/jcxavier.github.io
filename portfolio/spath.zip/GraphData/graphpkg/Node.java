package graphpkg;
import eapkg.Global;
import java.util.ArrayList;

/**
 * Implements a general node of a graph, and contains a <code>nodeID</code>, which
 * can only be accessed by methods of this class. It has also an ArrayList of objects of
 * the type {@link graphpkg.Route}Route (edges), which was the most efficient data structure
 * that was found to apply here. It is declared as protected so the child class {@link graphpkg.City}
 * City can access it. It implements a Comparable interface so that the objects can be put into a
 * PriorityQueue by the {@link eapkg.DijkstraEngine} class.
 * 
 * @author Jo�o Xavier / ei06116
 * @author Jo�o Ribeiro / ei06019
 * @version 1.337
 */
public class Node implements Comparable<Node>
{
	/**
	 * Unique identification of the node.
	 */
	private int nodeID;
	/**
	 * Container of all edges (Route) that link to this node.
	 */
	protected ArrayList<Route> destinations;
	
	/**
	 * Constructor of the class Node, takes nodeID as the only parameter.
	 * 
	 * @param nodeID the unique ID assigned to a node
	 */
	public Node(int nodeID)
	{
		this.nodeID = nodeID;
		this.destinations = new ArrayList<Route>();
	}
	
	/** 
	 * Retrieves the private int nodeID.
	 * 
	 * @return the private int nodeID
	 */
	public int getNodeID()
	{
		return nodeID;
	}
	
	/** 
	 * Retrieves the private ArrayList<Route> destinations.
	 * 
	 * @return the private ArrayList<Route> destinations
	 */
	public ArrayList<Route> getDestinations()
	{
		return destinations;
	}
	
	/**
	 * Appends the Route r into the ArrayList<Route> destinations.
	 * 
	 * @param r route to add to the ArrayList<Route> destinations
	 */
	public void addRoute(Route r)
	{	
		destinations.add(r);
	}
	
	/**
	 * Compares two objects of the class Node using its corresponding
	 * value on the array dist from the Global class.
	 */
	public int compareTo(Node x)
	{
		Integer a = Global.dist[this.nodeID], b = Global.dist[x.nodeID];		
		return a.compareTo(b);
	}
}
