package graphpkg;

/**
 * Implements a edge in the graph. It features two distinct weights,
 * <code>distance</code> and <code>duration</code>. Both can be used to compute
 * the shortest path between two nodes in the graph. Route contains the index
 * ({@link graphpkg.Node.nodeID}) of the node it connects to as well.
 * 
 *	@author Jo�o Xavier / ei06116
 *	@author Jo�o Ribeiro / ei06019
 *	@version 1.337
 */
public class Route
{
	/**
	 * The index of the node this route connects to.
	 */
	private int destination;
	/**
	 * Weight of the edge (distance).
	 */
	private int distance;
	/**
	 * Weight of the edge (duration).
	 */
	private int duration;

	/**
	 * Constructor of the class Route, takes three parameters and assigns them
	 * to the corresponding variables.
	 * 
	 * @param destination the index of the node this route connects to
	 * @param distance weight of the edge
	 * @param duration weight of the edge
	 */
	public Route(int destination, int distance, int duration)
	{
		this.destination = destination;
		this.distance = distance;
		this.duration = duration;
	}
	
	/** 
	 * Retrieves the private int destination.
	 * 
	 * @return the private int destination
	 */
	public int getDestination()
	{
		return destination;
	}
	
	/** 
	 * Retrieves the weight of the graph based on isDistance.
	 * 
	 * @return the private int distance if true, duration if false
	 */
	public int getWeight(boolean isDistance)
	{
		return (isDistance ? distance : duration);
	}
}
