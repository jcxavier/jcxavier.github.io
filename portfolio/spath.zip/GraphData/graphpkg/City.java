package graphpkg;

/**
 * Inherited from the class {@link graphpkg.Node} since it operates the same way
 * as a node, only adding the coordinates information in order to be visualisable.
 * 
 * @author Jo�o Xavier / ei06116
 * @author Jo�o Ribeiro / ei06019
 * @version 1.337
 */
public class City extends Node
{
	/**
	 * Coordinate information on the X axis.
	 */
	private int coordX;
	/**
	 * Coordinate information on the Y axis.
	 */
	private int coordY;
	
	/**
	 * Constructor of the class City, which calls the inherited constructor from Node
	 * and also declares the coordinate information.
	 * 
	 * @param nodeID the unique ID assigned to a node
	 * @param x coordinate on the X axis
	 * @param y coordinate on the Y axis
	 */
	public City(int nodeID, int x, int y)
	{
		super(nodeID);
		this.coordX = x;
		this.coordY = y;
	}
	
	/** 
	 * Retrieves the private int coordX.
	 * 
	 * @return the private int coordX
	 */
	public int getCoordX()
	{
		return coordX;
	}
	
	/** 
	 * Retrieves the private int coordY.
	 * 
	 * @return the private int coordY
	 */
	public int getCoordY()
	{
		return coordY;	
	}
}
