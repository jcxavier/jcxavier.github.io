package guipkg;
import guipkg.ShortestPathDialog;
import eapkg.DijkstraEngine;
import eapkg.Global;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.Dimension;
import javax.swing.JDesktopPane;
import javax.swing.JButton;
import java.awt.Rectangle;
import java.awt.Point;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import java.awt.SystemColor;
import java.awt.Font;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.BorderFactory;
import javax.swing.border.BevelBorder;

/**
 * Provides a graphical interface for the shortest path program. It features
 * two label boxes where the source node and the destination node can be inserted,
 * two radio buttons in order to select the type of weight desired to be computed
 * by the algorithm. Has a robust way of dealing with exceptions, making a popup
 * dialog appear if any parameter is wrong, and it also provides a vertical scroll
 * bar to use in the main display.
 * 
 * @author Jo�o Xavier / ei06116
 * @author Jo�o Ribeiro / ei06019
 * @version 1.337
 */
public class ShortestPathGUI extends JFrame
{
	private static final long serialVersionUID = 1L;
	private JPanel mainPanel = null;
	private JDesktopPane desktopPane = null;
	private JButton calculateButton = null;
	private JDesktopPane downBar = null;
	private JLabel sourceLabel = null;
	private JLabel destLabel = null;
	private JRadioButton distButton = null;
	private JRadioButton durationButton = null;
	private JLabel algOptionLabel = null;
	private JLabel distanceOptionLabel = null;
	private JLabel durationOptionLabel = null;
	private JTextField sourceText = null;
	private JTextField destText = null;
	private JTextArea pathText = null;
	private JScrollPane shortestPathScrollPane = null;
	
	/**
	 * Constructor of the class ShortestPathGUI, calls the super constructor and
	 * initializes the object.
	 */
	public ShortestPathGUI() {
		super();
		initialize();
	}

	/**
	 * Initializes this frame as a non-resizable 850x750 frame and with two radio
	 * buttons (being the distance button active by default).
	 */
	private void initialize() {
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(new Rectangle(200, 100, 850, 750));
		this.setResizable(false);
		this.setContentPane(getMainPanel());
		this.setTitle("Shortest Path");
		this.distButton.setSelected(true);
		this.durationButton.setSelected(false);
		this.setVisible(true);
	}

	/**
	 * Initializes mainPanel to contain the desktop pane.
	 * 
	 * @return javax.swing.JPanel the updated jPanel
	 */
	private JPanel getMainPanel() {
		if (mainPanel == null) {
			mainPanel = new JPanel();
			mainPanel.setLayout(new BorderLayout());
			mainPanel.setPreferredSize(new Dimension(120, 100));
			mainPanel.setVisible(true);
			mainPanel.add(getDesktopPane(), BorderLayout.CENTER);
		}
		return mainPanel;
	}

	/**
	 * Initializes desktopPane wih a bottom bar and a vertical scroll bar.
	 * 	
	 * @return javax.swing.JDesktopPane	the updated jDesktopPane
	 */
	private JDesktopPane getDesktopPane() {
		if (desktopPane == null) {
			desktopPane = new JDesktopPane();
			desktopPane.setDragMode(JDesktopPane.OUTLINE_DRAG_MODE);
			desktopPane.setEnabled(true);
			desktopPane.add(getDownBar(), null);
			desktopPane.setVisible(true);
			desktopPane.add(getShortestPathScrollPane(), null);
		}
		return desktopPane;
	}

	/**
	 * Initializes calculateButton with the thext "go!". When it is clicked, checks
	 * the fields for correction and displays a dialog panel if they aren't correct.
	 * If they are, then the shortest path algorithm is run and displayed on the main
	 * text area.
	 * 	
	 * @return javax.swing.JButton the updated jButton
	 */
	private JButton getCalculateButton() {
		if (calculateButton == null) {
			calculateButton = new JButton();
			calculateButton.setSize(new Dimension(51, 18));
			calculateButton.setText("go!");
			calculateButton.setHorizontalTextPosition(SwingConstants.CENTER);
			calculateButton.setEnabled(true);
			calculateButton.setLocation(new Point(780, 7));
			calculateButton.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e) {
					try
					{
						int source = Integer.parseInt(sourceText.getText().trim());
						int destination = Integer.parseInt(destText.getText().trim());
						if (source < 1 || destination < 1 || source > Global.MAX_CITIES || destination > Global.MAX_CITIES)
							throw new InvalidParameterException();
						
						Boolean algOption = (distButton.isSelected()? true : false);
						String value = algOption ? "distance" : "duration";
						
						long init = System.currentTimeMillis();
						ArrayList<Integer> shortestPath = new DijkstraEngine().Dijkstra(Global.map, source, destination, algOption);
						long end = System.currentTimeMillis(), z = end - init;
						
						pathText.setText("Shortest path computed for " + value + " in " + (z/1000.0) + " seconds:\n" + arrayToPathString(shortestPath));
					}
					catch (NumberFormatException nfe){
						new ShortestPathDialog().setDialogText("ERROR: invalid parameters");
					}
					catch (InvalidParameterException ipe) {
						new ShortestPathDialog().setDialogText("ERROR: invalid cities (1-" + Global.MAX_CITIES + ")");
					}
				}
			});
		}
		return calculateButton;
	}

	/**
	 * Initializes downBar in the bottom of the desktop pane. Contains two text fields
	 * for inputting source and destination nodes, two radio buttons to select between
	 * the weights desired to compute in the shortest path algorithm and the "go!" button,
	 * for running the algorithm.
	 * 	
	 * @return javax.swing.JDesktopPane	the jDesktopPane updated
	 */
	private JDesktopPane getDownBar() {
		if (downBar == null) {
			durationOptionLabel = new JLabel();
			durationOptionLabel.setText("duration");
			durationOptionLabel.setSize(new Dimension(54, 20));
			durationOptionLabel.setLocation(new Point(691, 6));
			durationOptionLabel.setHorizontalAlignment(SwingConstants.LEFT);
			distanceOptionLabel = new JLabel();
			distanceOptionLabel.setText("distance");
			distanceOptionLabel.setSize(new Dimension(55, 19));
			distanceOptionLabel.setLocation(new Point(603, 6));
			distanceOptionLabel.setHorizontalAlignment(SwingConstants.LEFT);
			algOptionLabel = new JLabel();
			algOptionLabel.setHorizontalAlignment(SwingConstants.RIGHT);
			algOptionLabel.setSize(new Dimension(159, 18));
			algOptionLabel.setLocation(new Point(410, 7));
			algOptionLabel.setText("calculate path for shortest:");
			destLabel = new JLabel();
			destLabel.setText("destination:");
			destLabel.setLocation(new Point(157, 5));
			destLabel.setSize(new Dimension(70, 20));
			destLabel.setHorizontalAlignment(SwingConstants.RIGHT);
			destLabel.setToolTipText("choose a destination city");
			sourceLabel = new JLabel();
			sourceLabel.setToolTipText("choose a starting city");
			sourceLabel.setLocation(new Point(8, 5));
			sourceLabel.setSize(new Dimension(46, 20));
			sourceLabel.setHorizontalTextPosition(SwingConstants.CENTER);
			sourceLabel.setHorizontalAlignment(SwingConstants.RIGHT);
			sourceLabel.setText("source:");
			downBar = new JDesktopPane();
			downBar.setLocation(new Point(0, 694));
			downBar.setSize(new Dimension(845, 30));
			downBar.setBackground(SystemColor.controlHighlight);
			downBar.add(getCalculateButton(), null);
			downBar.add(sourceLabel, null);
			downBar.add(destLabel, null);
			downBar.add(getDistButton(), null);
			downBar.add(getDurationButton(), null);
			downBar.add(algOptionLabel, null);
			downBar.add(distanceOptionLabel, null);
			downBar.add(durationOptionLabel, null);
			downBar.add(getSourceText(), null);
			downBar.add(getDestText(), null);
		}
		return downBar;
	}
	
	/**
	 * Initializes distButton as a radio button. It is enabled whenever durationButton
	 * is disabled.
	 * 	
	 * @return javax.swing.JRadioButton the jRadioButton updated
	 */
	private JRadioButton getDistButton() {
		if (distButton == null) {
			distButton = new JRadioButton();
			distButton.setToolTipText("select to calculate the path using the ");
			distButton.setSize(new Dimension(21, 21));
			distButton.setLocation(new Point(582, 6));
			distButton.setBackground(SystemColor.controlHighlight);
			distButton.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e) {
					distButton.setSelected(true);
					durationButton.setSelected(false);
				}
			});
		}
		return distButton;
	}

	/**
	 * Initializes durationButton as a radio button. It is enabled whenever distButton
	 * is disabled.
	 * 	
	 * @return javax.swing.JRadioButton the jRadioButton updated
	 */
	private JRadioButton getDurationButton() {
		if (durationButton == null) {
			durationButton = new JRadioButton();
			durationButton.setBackground(SystemColor.controlHighlight);
			durationButton.setLocation(new Point(670, 6));
			durationButton.setSize(new Dimension(21, 21));
			durationButton.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e) {
					durationButton.setSelected(true);
					distButton.setSelected(false);
				}
			});
		}
		return durationButton;
	}

	/**
	 * Initializes the sourceText field, where the source node will be inputted.
	 * 	
	 * @return javax.swing.JTextField the jTextField updated
	 */
	private JTextField getSourceText() {
		if (sourceText == null) {
			sourceText = new JTextField();
			sourceText.setLocation(new Point(61, 7));
			sourceText.setSize(new Dimension(70, 18));
		}
		return sourceText;
	}

	/**
	 * Initializes the destText field, where the destination node will be inputted.
	 * 	
	 * @return javax.swing.JTextField the jTextField updated
	 */
	private JTextField getDestText() {
		if (destText == null) {
			destText = new JTextField();
			destText.setSize(new Dimension(70, 18));
			destText.setLocation(new Point(235, 7));
		}
		return destText;
	}

	/**
	 * Initializes pathText as a non-editable text area with a monospaced font.	
	 * 	
	 * @return javax.swing.JTextArea the jTextArea updated
	 */
	private JTextArea getPathText() {
		if (pathText == null) {
			pathText = new JTextArea();
			pathText.setRows(30);
			pathText.setFont(new Font("Monospaced", Font.PLAIN, 12));
			pathText.setEditable(false);
			pathText.setLineWrap(true);
		}
		return pathText;
	}
	
	/**
	 * Returns a string with leading whitespaces with length 6.
	 * 
	 * @param s string to fill with leading whitespaces
	 * 
	 * @return the string with leading whitespaces
	 */
	private String whiteSpace(String s)
	{
		String blank = "";
		for (int j = 6; j != s.length(); j--)
			blank += " ";
		
		return blank;
	}
	
	/**
	 * Converts the ArrayList<Integer> path to a string representation of the array.
	 * A newline is inserted every 14 numbers so that the viewing is simpler.
	 * 
	 * @param path the shortest path array
	 * 
	 * @return the string representation of the array
	 */
	public String arrayToPathString(ArrayList<Integer> path)
	{
		String pathString = whiteSpace(path.get(0).toString()) + path.get(0) + ", ";
		for(int i=1; i != (path.size()-1); i++)
		{
			String temp = path.get(i).toString();
			
			pathString += whiteSpace(temp) + temp + ", ";
			if(i % 14 == 13)
				pathString += "\n";
		}
		pathString += whiteSpace(path.get(path.size()-1).toString()) + path.get(path.size()-1);
		
		return pathString;
	}

	/**
	 * Initializes the shortestPathScrollPane, which implements a vertical scroll bar.
	 * 	
	 * @return javax.swing.JScrollPane the updated jScrollPane
	 */
	private JScrollPane getShortestPathScrollPane() {
		if (shortestPathScrollPane == null) {
			shortestPathScrollPane = new JScrollPane();
			shortestPathScrollPane.setBounds(new Rectangle(0, 0, 844, 695));
			shortestPathScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
			shortestPathScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			shortestPathScrollPane.setViewportBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
			shortestPathScrollPane.setViewportView(getPathText());
		}
		return shortestPathScrollPane;
	}
	

}  //  @jve:decl-index=0:visual-constraint="16,11"
