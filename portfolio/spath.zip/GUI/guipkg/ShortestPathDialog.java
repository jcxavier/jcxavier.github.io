package guipkg;
import javax.swing.JPanel;
import javax.swing.JDialog;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.awt.Point;
import java.awt.Dimension;
import javax.swing.JButton;

/**
 * Pops up when a error occurs, such as invalid parameters or invalid node indexes.
 * 
 * @author Jo�o Xavier / ei06116
 * @author Jo�o Ribeiro / ei06019
 * @version 1.337
 */
public class ShortestPathDialog extends JDialog
{
	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JButton dialogButton = null;
	private JLabel dialogLabel = null;

	/**
	 * Constructor of the class ShortestPathDialog, calls the super constructor and
	 * initializes the object.
	 */
	public ShortestPathDialog() {
		super();
		initialize();
	}

	/**
	 * Initializes this object as a non-resizable 300x130 window.
	 */
	private void initialize() {
		this.setSize(300, 130);
		this.setResizable(false);
		this.setPreferredSize(new Dimension(300, 200));
		this.setLocation(new Point(475, 400));
		this.setVisible(true);
		this.setContentPane(getJContentPane());
	}

	/**
	 * Initializes jContentPane with the dialog label.
	 * 
	 * @return javax.swing.JPanel the jContentPane updated
	 */
	public JPanel getJContentPane() {
		if (jContentPane == null) {
			dialogLabel = new JLabel();
			dialogLabel.setBounds(new Rectangle(30, 14, 235, 46));
			dialogLabel.setName("DialogLabel");
			dialogLabel.setText("");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.setVisible(true);
			jContentPane.add(getDialogButton(), null);
			jContentPane.add(dialogLabel, null);
		}
		return jContentPane;
	}
	
	/**
	 * Updates the information of the dialog label with the string str.
	 * 
	 * @param str string to update
	 */
	public void setDialogText(String str)
	{
		dialogLabel.setText(str);
	}
	
	/**
	 * Initializes dialogButton with the text "OK" which exits the window when
	 * pressed.
	 * 	
	 * @return javax.swing.JButton the jButton updated
	 */
	private JButton getDialogButton() {
		if (dialogButton == null) {
			dialogButton = new JButton();
			dialogButton.setText("OK");
			dialogButton.setSize(new Dimension(60, 20));
			dialogButton.setLocation(new Point(120, 75));
			dialogButton.setPreferredSize(new Dimension(40, 20));
			dialogButton.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e) {
					getOwner().dispose();
				}
			});
		}
		return dialogButton;
	}
}  //  @jve:decl-index=0:visual-constraint="10,10"
