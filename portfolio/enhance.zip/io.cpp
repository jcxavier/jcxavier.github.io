#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstring>
using namespace std;
#include "io.h"

inline char * clearSpaces(char*c){
	while(isspace(*c))c++;
	return c;
}

inline char * clearLine(char*c){
	while(*c && *c != '\n')c++;
	if(*c == '\n') 
		return c + 1;
	return c;
}

int nextInt(char * buf, char**end, char comment='#'){
	buf=clearSpaces(buf);
	while(*buf){
		if(*buf==comment)//comment
			buf=clearLine(buf);
		else if(isdigit(*buf)){//number
			char * btmp;
			int tmp=strtol(buf,&btmp,10);
			if(buf==btmp)//no numbers
				break;
			*end=btmp;
			return tmp;
		}else
			break;
		buf=clearSpaces(buf);
	}
	throw string("Error while reading file");
}


uchar * readImage(const char* path, uint & w, uint & h){
	ifstream f(path);
	char * data, *current;
	uint l, max;	

	f.seekg (0, ios::end);
	l=f.tellg();

	current=data=new char[l+1];

	f.seekg (0, ios::beg);
	f.read (data,l);
	f.close();
	data[l]=0;


	if(strncmp("P3",data,2)){
		data[2]=0;
		string error = "Invalid file type: \"";
		error += string(data);
		error += "\"";
		//delete data;
		throw error;
		//throw string("Invalid file type");
	}

	current+=2;

	w=nextInt(current, &current);
	h=nextInt(current, &current);
	max=nextInt(current, &current);

	cout<<"Resolution: "<<w<<"x"<<h<<endl;

	uint num_samples = numSamples(w, h);
	
	unsigned char * buf = new unsigned char [num_samples];

	for(uint s=0;s<num_samples;s++)
		buf[s]=nextInt(current, &current)*255l/max;

	delete data;
	return buf;
}


void writeImage(const char* path, const uchar * i, uint w, uint h){
	FILE* ofp;
	ofp = fopen(path, "w");

	if (ofp == NULL)
		throw string("Can't open output file");

	uint n = numSamples(w,h);

	fprintf(ofp, "P3\n%d %d\n255\n", w, h);

	for (uint a = 0; a != n; a++)
		fprintf(ofp, "%d\n", a[i]);

	fclose(ofp);
}

void writeImageBinary(const char* path, const uchar * i, uint w, uint h){
	ofstream f(path);
	f<<"P6"<<endl;
	f<<w<<" "<<h<<endl;
	f<<255<<endl;
	
	f.write((char*)i,numSamples(h,w));
	f.close();
}
