#ifndef __CONFIG_H__
#define __CONFIG_H__
typedef unsigned int uint;
typedef unsigned char uchar;
#endif
