#ifndef __IMAGE_H__
#define __IMAGE_H__
#include "config.h"
#define getRed(x) ((x)[0])
#define getGreen(x) ((x)[1])
#define getBlue(x) ((x)[2])
#define nextPixel(x) ((x)+3)
#define pixelEquals(x,y) (((x[0])==(y[0])) && ((x[1])==(y[1])) && ((x[2])==(y[2])))
#define get(buf, w, x, y) ((buf)+(((y)*(w))+(x))*3)
#define numSamples(w,h) ((w)*(h)*3)
#define lineBytes(x) ((x)*3)
#endif
