#ifndef __INPUT_H_
#define __INPUT_H_
#include "image.h"

unsigned char * readImage(const char* path, uint & width, uint & heigth);
void writeImage(const char* path, const uchar * i, uint width, uint height);
#endif
