#include <ctime>
#include <string>
#include <iostream>
#include <algorithm>
#include <limits>
#include <cstdlib>
#include <cstring>

#include "algorithm.h"
#include "image.h"
#include "io.h"
using namespace std;


int enhance(uchar * in, uchar * out, uint w, uint h, int steps){
	uint num_samples=numSamples(w,h);
	uchar * a = new uchar[num_samples] , *b = new uchar[num_samples];
	//Init buffers
	memcpy(a, in, num_samples);
	memcpy(b, in, num_samples);

	int i,diff;
	for(i=0;i<steps;i++){
		diff=step(a, b, w, h);
		cout<<"Step: "<<i+1<<" Diffs: "<<diff<<endl;
		swap(a, b);
		if(!diff)
			break;
	}
	memcpy(out, a, num_samples);
	return i;
}



int main(int argc, char** argv){
	if(argc != 4){
		cout<<"Usage: "<<argv[0]<<" <input> <output> <steps>"<<endl;
		return 1;
	}

	try{
		clock_t read_init, read_end, proc_init, proc_end, write_init, write_end;

		// Reading from file
		cout << "Reading from file..." << endl;
		read_init = clock();
		uint w,h;
		uchar * in=readImage(argv[1],w,h);
		uint num_samples=numSamples(w,h);
		uchar * out = new uchar[num_samples];
		
		read_end = clock();
		cout << "Success!" << endl << endl;

		// Image processing
		cout << "Processing image..." << endl;
		proc_init = clock();
		int steps=enhance(in,out,w,h,atoi(argv[3]));
		proc_end = clock();
		cout<<"Success! Done in "<<steps<<" steps."<<endl<<endl;
		
		// Writing to file
		cout << "Writing to file..." << endl;
		write_init = clock();
		writeImage(argv[2],out,w,h);
		write_end = clock();
		cout << "Success!" << endl << endl;
		delete in;

		// Benchmarking
		cout << endl << "BENCHMARKING" << endl;
		cout << "Reading: " << (read_end - read_init)/(float)CLOCKS_PER_SEC << " s" << endl;
		cout << "Processing: " << (proc_end - proc_init)/(float)CLOCKS_PER_SEC << " s" << endl;
		cout << "Writing: " << (write_end - write_init)/(float)CLOCKS_PER_SEC << " s" << endl;

	}catch(string e){
		cout<<"Exception: "<<e<<endl;
	}

}



