#include <ctime>
#include <string>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <limits>
#include <cstdlib>
#include <cstring>
#include <mpi.h>
#include <vector>
#include <cmath>
#include <iomanip>

#include "algorithm.h"
#include "image.h"
#include "io.h"
using namespace std;

#define LINES 0
#define WIDTH 1
#define DATA 2
#define DIFF 3

int round(float x) { return int(x+0.5f); } 

void master(int np, int id, char * inPath, char * outPath, int iterations) {
		clock_t read_init, read_end, proc_init, proc_end, write_init, write_end;

		cout << "Reading from file..." << endl;
		
		read_init = clock();
		
		MPI_Status status;
		uint w,h, num_samples;
		uchar * in, *out;
		
		in=readImage(inPath,w,h);
		num_samples=numSamples(w,h);
		out = new uchar[num_samples];
		memcpy(out, in, lineBytes(w));
		memcpy(get(out,w, 0, h-1), get(in, w, 0, h-1), lineBytes(w));
		

		read_end = clock();
		
		cout << "Success!" << endl << endl;
		
		//Processing	
		vector < pair <uint, uint> > range(np);


		proc_init = clock();
		//Startup comm
		uint pos = 1;
		uint tmp;

		range[0].first = pos;
		range[0].second = round((h - pos - 2) / float(np));
		pos += range[0].second;
		cout <<"ID: "<<0<< " Processing "<<range[0].second<<" lines Begin: "<<range[0].first<<" End: "<<(range[0].first+range[0].second)<<endl;

		for (int i=1; i<np; i++){
			MPI_Send(&w, 1, MPI_UNSIGNED, i, WIDTH, MPI_COMM_WORLD);
			range[i].first = pos;
			range[i].second = round((h - pos - 2) / float(np - i));
			pos += range[i].second;
			cout <<"ID: "<<i<< " Processing "<<range[i].second<<" lines Begin: "<<range[i].first<<" End: "<<(range[i].first+range[i].second)<<endl;
			
			tmp=range[i].second + 2;
			MPI_Send(&tmp, 1, MPI_UNSIGNED, i, LINES, MPI_COMM_WORLD);
			MPI_Send(get(in, w, 0, range[i].first - 1), numSamples(w, tmp), MPI_UNSIGNED_CHAR, i, DATA, MPI_COMM_WORLD);
		}

		cout << endl;
		cout <<"ID: "<<id <<" Width: "<<w<<" Height:"<<range[0].second + 2<<endl; 

		uint diffs;
		if (iterations > 0)
		{
			diffs = 0;
			diffs += step(in, in, w, range[0].second + 2);

			//Receber a fronteira
			if (np > 1)
				MPI_Recv(get(in, w, 0, range[1].first), lineBytes(w), MPI_UNSIGNED_CHAR, 1, DATA, MPI_COMM_WORLD, &status);
			
			for (int i=1; i<np; i++){
				MPI_Recv(&tmp, 1, MPI_UNSIGNED, i, DIFF, MPI_COMM_WORLD, &status);
				diffs+=tmp;
			}

			cout<<"Iteration 0: "<<diffs <<" diffs"<<endl;
		}

		for(int it=1; it<iterations-1; it++){
			diffs=0;

			// Enviar a linha adjacente
			if (np > 1)
			{
				// Enviar a linha adjacente
				MPI_Send(get(in, w, 0, range[1].first - 1), lineBytes(w), MPI_UNSIGNED_CHAR, 1, DATA, MPI_COMM_WORLD);
				
				// Processar (Master at work)
				diffs += step(in, in, w, range[0].second + 2);

				//Receber a fronteira
				MPI_Recv(get(in, w, 0, range[1].first), lineBytes(w), MPI_UNSIGNED_CHAR, 1, DATA, MPI_COMM_WORLD, &status);
			}
			else
				diffs += step(in, in, w, range[0].second + 2);


			for (int i=1; i<np; i++){
				MPI_Recv(&tmp, 1, MPI_UNSIGNED, i, DIFF, MPI_COMM_WORLD, &status);
				diffs+=tmp;
			}

			cout<<"Iteration "<<it<<": "<<diffs <<" diffs"<<endl;
		}


		if (iterations > 1)
		{
			diffs=0;

			// Enviar a linha adjacente
			if (np > 1)
				MPI_Send(get(in, w, 0, range[1].first - 1), lineBytes(w), MPI_UNSIGNED_CHAR, 1, DATA, MPI_COMM_WORLD);
			
			diffs += step(in, in, w, range[0].second + 2);

			for (int i=1; i<np; i++){
				MPI_Recv(&tmp, 1, MPI_UNSIGNED, i, DIFF, MPI_COMM_WORLD, &status);
				diffs+=tmp;
			}

			cout<<"Iteration "<<iterations-1<<": "<<diffs <<" diffs"<<endl;
		}

		memcpy(out, in, num_samples);

		//Collect all
		for (int i=1; i<np; i++)
			MPI_Recv(get(out, w, 0, range[i].first), numSamples(w, range[i].second), MPI_UNSIGNED_CHAR, i, DATA, MPI_COMM_WORLD, &status);
		
		proc_end = clock();
		
		// Writing to file
		cout << endl << "Writing to file..." << endl;
	
		write_init = clock();
		writeImage(outPath,out,w,h);
		write_end = clock();
		cout << "Success!" << endl << endl;

		delete in;
		delete out;
		// Benchmarking
		cout << endl << "BENCHMARKING" << endl;
		cout << "Reading: " << (read_end - read_init)/(float)CLOCKS_PER_SEC << " s" << endl;
		cout << "Processing: " << (proc_end - proc_init)/(float)CLOCKS_PER_SEC << " s" << endl;
		cout << "Writing: " << (write_end - write_init)/(float)CLOCKS_PER_SEC << " s" << endl;
}

void worker(int np, int id, int iterations){
	int w, h;
	uint num_samples;	 
	uchar*buf;
	MPI_Status status;
	MPI_Recv(&w, 1, MPI_UNSIGNED, 0, WIDTH, MPI_COMM_WORLD, &status);
	MPI_Recv(&h, 1, MPI_UNSIGNED, 0, LINES, MPI_COMM_WORLD, &status);
	
	num_samples = numSamples(w,h);
	buf=new uchar[num_samples];

	MPI_Recv(buf, num_samples, MPI_UNSIGNED_CHAR, 0, DATA, MPI_COMM_WORLD, &status);

	cout <<"ID: "<<id <<" Width: "<<w<<" Height:"<<h<<endl; 
	/*
	for(int i=0;i<num_samples;i++)
		cout <<setw(2)<< (int)buf[i] << " ";
	cout << endl;
	*/

	uint diff;
	
	if (iterations > 0)
	{
		diff=step(buf, buf,w ,h);
		MPI_Send(&diff, 1, MPI_UNSIGNED, 0, DIFF, MPI_COMM_WORLD);
		MPI_Send(get(buf, w, 0, 1), lineBytes(w), MPI_UNSIGNED_CHAR, id-1, DATA, MPI_COMM_WORLD);
	}

	// �ltimo processo, n�o envia para a frente
	if (id+1 == np)
	{
		for(int i = 1; i < iterations-1; i++){
		//Receber as linhas adjacentes
			MPI_Recv(get(buf, w, 0, 0), lineBytes(w), MPI_UNSIGNED_CHAR, id-1, DATA, MPI_COMM_WORLD, &status);
			diff=step(buf, buf,w ,h);
			//Enviar linhas de fronteira
			MPI_Send(&diff, 1, MPI_UNSIGNED, 0, DIFF, MPI_COMM_WORLD);
			MPI_Send(get(buf, w, 0, 1), lineBytes(w), MPI_UNSIGNED_CHAR, id-1, DATA, MPI_COMM_WORLD);
		}

		if (iterations > 1)
			MPI_Recv(get(buf, w, 0, 0), lineBytes(w), MPI_UNSIGNED_CHAR, id-1, DATA, MPI_COMM_WORLD, &status);
	}
	else
	{
		if (iterations > 0)
			MPI_Send(get(buf, w, 0, h-2), lineBytes(w), MPI_UNSIGNED_CHAR, id+1, DATA, MPI_COMM_WORLD);

		for(int i = 1; i < iterations-1; i++){
			//Receber as linhas adjacentes
			MPI_Recv(get(buf, w, 0, 0), lineBytes(w), MPI_UNSIGNED_CHAR, id-1, DATA, MPI_COMM_WORLD, &status);
			MPI_Recv(get(buf, w, 0, h-1), lineBytes(w), MPI_UNSIGNED_CHAR, id+1, DATA, MPI_COMM_WORLD, &status);
			diff=step(buf, buf,w ,h);
			//Enviar linhas de fronteira
			MPI_Send(&diff, 1, MPI_UNSIGNED, 0, DIFF, MPI_COMM_WORLD);
			MPI_Send(get(buf, w, 0, 1), lineBytes(w), MPI_UNSIGNED_CHAR, id-1, DATA, MPI_COMM_WORLD);
			MPI_Send(get(buf, w, 0, h-2), lineBytes(w), MPI_UNSIGNED_CHAR, id+1, DATA, MPI_COMM_WORLD);
		}

		if (iterations > 1)
		{
			MPI_Recv(get(buf, w, 0, 0), lineBytes(w), MPI_UNSIGNED_CHAR, id-1, DATA, MPI_COMM_WORLD, &status);
			MPI_Recv(get(buf, w, 0, h-1), lineBytes(w), MPI_UNSIGNED_CHAR, id+1, DATA, MPI_COMM_WORLD, &status);
		}
	}

	if (iterations > 1)
	{
		diff=step(buf, buf,w ,h);
		//Enviar linhas de fronteira
		MPI_Send(&diff, 1, MPI_UNSIGNED, 0, DIFF, MPI_COMM_WORLD);
	}

	MPI_Send(get(buf, w, 0, 1), numSamples(w, h - 2), MPI_UNSIGNED_CHAR, 0, DATA, MPI_COMM_WORLD);
}


int main(int argc, char** argv){
	if(argc != 4){
		cout<<"Usage: "<<argv[0]<<" <input> <output> <steps>"<<endl;
		return 1;
	}

	int np, id;
	MPI_Init(&argc, &argv);
	MPI_Comm_size(MPI_COMM_WORLD, &np);
	MPI_Comm_rank(MPI_COMM_WORLD, &id);

	try {
		if (id == 0)
			master(np, id, argv[1], argv[2], atoi(argv[3]));
		else
			worker(np, id, atoi(argv[3]));
	}
	catch (const string & s){
		cout << "Fail: "<<s<<endl;
		
		MPI_Finalize( );

		return 1;
	}

	MPI_Finalize();
	
	return 0;
}



