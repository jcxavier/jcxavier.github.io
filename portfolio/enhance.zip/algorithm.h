#ifndef __ALGORITHM_H__
#define __ALGORITHM_H__
#include "config.h"
#include "image.h"

#include <algorithm>
#include <limits>
#include <cstdlib>
#include <cstring>
using namespace std;

template <class T>
inline T newValueChannel(const T target, T * N){
	T min, max, med;

	sort(N,N+8);
	if(N[0]>target){
		max=N[7];
		min=target;
		med=N[3];
	}else{
		max=target;
		min=N[0];
		med=N[4];
	}

	float pl, pd, tpl, tpd, val=0, Cdd, Cdl, Cld, Cll,delta;

	delta=(float)max-min;

	tpl=(target-min)/delta;
	tpd=1-tpl;
	
	Cll=1+(med-min)/delta;
	Cdd=2-(med-min)/delta;
	Cld=0.8f;
	Cdl=0.8f;
	for(int i=0;i<8;i++){ // Compute probabilities
		pl=(N[i]-min)/delta;
		pd=1-pl;
		val += (Cdl*pd+Cll*pl)
								/	(Cdd*pd*tpd + 
									Cdl*pl*tpd +
									Cld*pd*tpl +
									Cll*pl*tpl);
	}

	val *= 0.125f * tpl;
	
	if(int(val*10)>5){
		if(target<std::numeric_limits<T>::max())
			return target+1;
	} else if(int(val*10)<5)
		if(target>0)
			return target-1;
	
	return target;
}

inline void
newValue(const uchar * target, const uchar *  N0, const uchar * N1, const uchar * N2, 
															 const uchar *  N3, const uchar * N4, const uchar * N5, 
															 const uchar *  N6, const uchar * N7,
															 uchar * dest){

	uchar Nr[8]={getRed(N0),getRed(N1),getRed(N2),getRed(N3),getRed(N4),getRed(N5),getRed(N6),getRed(N7)};
	uchar Ng[8]={getGreen(N0),getGreen(N1),getGreen(N2),getGreen(N3),getGreen(N4),getGreen(N5),getGreen(N6),getGreen(N7)};
	uchar Nb[8]={getBlue(N0),getBlue(N1),getBlue(N2),getBlue(N3),getBlue(N4),getBlue(N5),getBlue(N6),getBlue(N7)};
	
	
	getRed(dest)=newValueChannel(getRed(target), Nr);
	getGreen(dest)=newValueChannel(getGreen(target), Ng);
	getBlue(dest)=newValueChannel(getBlue(target), Nb);
}

inline int 
step(const uchar * in, uchar* out, uint w, uint h){
	uint num_samples=numSamples(w,h);
	uchar *tmp = new uchar[num_samples];
	
	int diff=0;
	for(uint y=1;y<h-1;y++){
		memcpy(get(tmp, w, 0, y), get(in, w, 0, y), 3);
		memcpy(get(tmp, w, w - 1, y), get(in, w, w - 1, y), 3);
		for(uint x=1;x<w-1;x++){
			newValue(get(in, w, x, y), 
					get(in, w, x-1,y-1),	get(in, w, x,y-1),	get(in, w, x+1,y-1),
					get(in, w, x-1,y),												get(in, w, x+1,y),
					get(in, w, x-1,y+1),	get(in, w, x,y+1),	get(in, w, x+1,y+1),
					get(tmp, w, x, y)
					);
			if (!pixelEquals(get(in, w, x, y), get(tmp, w, x, y))) 
				diff++;
		}
	}
	memcpy(get(out, w, 0, 1), get(tmp, w, 0, 1), num_samples - lineBytes(w) * 2);
	delete tmp;
	return diff;
}

#endif
