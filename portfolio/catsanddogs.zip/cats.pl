%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% CATS & DOGS  %%%%%%
%%%%%%    PROLOG    %%%%%%
%%%%%%  2008.11.02  %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%
% Jo�o Xavier  - ei06116 %
% Jo�o Ribeiro - ei06019 %
%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%% BRIEF DESCRIPTION AND RULES %%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The concept of Cats & Dogs is quite simple.                                 %
% On each turn, each player drops one of his pets into an empty cell.         %
% However, the cell where the new animal is dropped cannot be orthogonally    %
% adjacent to a different animal (i.e, no dogs and cats close to each other). %
% Wins the player that after there is no more valid moves, has more animals   %
% on board.                                                                   %
%                                                                             %
%                  abridged and adapted from "Games of Soldiers: CATS & DOGS" %
%                            http://homepages.di.fc.ul.pt/~jpn/gv/catdogs.htm %
%                                                                             %
% Features:                                                                   %
% - Special moves (once in a few turns, cats can take a dog off the board,    %
% while dogs can put two pieces in one turn);                                 %
% - Randomized, dynamic obstacle board: instead of the typical clean 8x8      %
% board, this version features obstacles on the board and asks the user to    %
% input the board size;                                                       %
% - 3 different levels of AI: can you beat them all?                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% :-use_module(library(sockets)).



%%%%%%%%%%%%%%%%%%
%%%% GAMEPLAY %%%%
%%%%%%%%%%%%%%%%%%

%begin()
begin:-
       abolish(player/3),
       introduction,
       chooseGameType,
       chooseBoardSize(Size),
       generateBoard(Size, Board),
       Player is random(2)+1,
       play(Board, Player, Size, 1).

%play(+Board, +Player, +Size, +Turn)
play(Board, Player, Size, Turn):-
       moveList(Board, Player, MoveList, 0),
       moveCount(Board, Player, Count, 0),
       NextTurn is Turn+1,
       SpecialMove is Turn mod (Size*2),
       drawBoard(Board, Size),
       nl, writePlayer(Player), write('� turn:'), nl,
       ((SpecialMove =:= (Size*2-1) ; SpecialMove =:= 0) ->
              specialMove(Board, Player, Size, NextTurn, MoveList, Count), !;
              changePlayer(Player, NextPlayer),
              (Count =:= 0 ->
                     moveCount(Board, NextPlayer, Count2, 0),
                     write('No moves available!'), nl,
                     (Count2 =:= 0 ->
                            endGame(Board, Size), !;
                            play(Board, NextPlayer, Size, NextTurn));
                     player(Player, PlayerType, AI),
                     getMove(PlayerType, MoveList, Move, Size, AI),
                     validMove(Board, Player, Move, 0),
                     assignMove(0, Player, Move, Board, NewBoard),
                     play(NewBoard, NextPlayer, Size, NextTurn))).

%changePlayer(+P1, -P2)
changePlayer(0, 1).
changePlayer(1, 2).
changePlayer(2, 1).

%writePlayer(+Player)
writePlayer(1):- write('Cats').
writePlayer(2):- write('Dogs').

%endGame(+Board, +Size)
endGame(Board, Size):-
       drawBoard(Board, Size),
       countPieces(Board, 1, Count1), countPieces(Board, 2, Count2),
       write(Count1), write(' - '), write(Count2), nl,
       (Count1 > Count2, write('Cats win!');
       Count1 < Count2,  write('Dogs win !');
       write('Draw!')).
      


%%%%%%%%%%%%%%%%%%
%%%% START-UP %%%%
%%%%%%%%%%%%%%%%%%

%introduction()
introduction:-
       nl, write('Cats & Dogs - Prolog - 2008.11.02'),
       nl, write('Joao Xavier'),
       nl, write('Joao Ribeiro'), nl, nl.

%chooseGameType()
chooseGameType:-
       write('Input game mode:'), nl,
       write('Cats: '), nl, write('1 - Human, 2 - CPU'), nl,
       repeat, readNumber(Cats), Cats>=1, Cats=<2, nl,
       write('Dogs: '), nl, write('1 - Human, 2 - CPU'), nl,
       repeat, readNumber(Dogs), Dogs>=1, Dogs=<2, nl,
       gameType(Cats, Dogs, P1, P2),
       selectAI(Cats, Dogs, AI1, AI2),
       assert(player(1, P1, AI1)), assert(player(2, P2, AI2)).

%gameType(+Cats, +Dogs, -P1, -P2)
gameType(1, 1, human, human).
gameType(1, 2, human, comp ).
gameType(2, 1, comp,  human).
gameType(2, 2, comp,  comp ).

%selectAI(+Cats, +Dogs, -AI1, -AI2)
selectAI(1, 1, 0, 0).
selectAI(1, 2, 0, AI):-
       write('Input CPU (Dogs) Level:'), nl, write('1 - Easy, 2 - Medium, 3 - Hard'), nl,
       repeat, readNumber(AI), AI>=1, AI=<3, nl.
selectAI(2, 1, AI, 0):-
       write('Input CPU (Cats) Level:'), nl, write('1 - Easy, 2 - Medium, 3 - Hard'), nl,
       repeat, readNumber(AI), AI>=1, AI=<3, nl.
selectAI(2, 2, AI1, AI2):-
       write('Input CPU (Cats) Level:'), nl,
       write('1 - Easy, 2 - Medium, 3 - Hard'), nl,
       repeat, readNumber(AI1), AI1>=1, AI1=<3, nl,
       write('Input CPU (Dogs) Level:'), nl,
       write('1 - Easy, 2 - Medium, 3 - Hard'), nl,
       repeat, readNumber(AI2), AI2>=1, AI2=<3, nl.

%chooseBoardSize(-Size)
chooseBoardSize(Size):-
       write('Choose a board size between 4 and 12:'), nl,
       repeat, readNumber(Size), Size>=4, Size=<12, nl.



%%%%%%%%%%%%%%%%%%%%%
%%%% MOVE PARSER %%%%
%%%%%%%%%%%%%%%%%%%%%

%getMove(+PlayerType, +MoveList, -Move, +Size, +AI)
getMove(human, _, Move, Size, _):- inputMove(Move, Size).
getMove(comp, MoveList, Move, _, AI):- computeMove(AI, MoveList, Move).

%readNumber(-Num)
readNumber(Num):-
       readln(Line),
       lengthList(Line, ListLen),
       ListLen =:= 1,
       Line = [Num|_],
       integer(Num).

%readCharCode(-CharCode)
readCharCode(CharCode):-
       readln(Line),
       lengthList(Line, ListLen),
       ListLen =:= 1,
       Line = [String|_],
       atom(String),
       atom_codes(String, CharCodeList),
       lengthList(CharCodeList, StrLen),
       StrLen =:= 1,
       CharCodeList = [CharCode|_].

%inputMove(-Move, +Size)
inputMove(Move, Size):-
       repeat,
       write('X: '), readCharCode(SX), convertAlpha(SX,X,Size),
       write('Y: '), readNumber(Y), Y>=1, Y=<Size,
       cons(X, Y, Move).

%convertAlpha(+Let, -Val, +Size)
convertAlpha(Let, Val, Size):- isUpper(Let, Size), Val is Let-64.
convertAlpha(Let, Val, Size):- isLower(Let, Size), Val is Let-96.

%isUpper(+Let, +Size)
isUpper(Let, Size):- Let>=65, UpperLimit is 65+Size, Let<UpperLimit.
%isLower(+Let, +Size)
isLower(Let, Size):- Let>=97, UpperLimit is 97+Size, Let<UpperLimit.



%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% BOARD GENERATION %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%

%generateBoard(+Size, -Board)
generateBoard(Size, Board):-
       genListLists(0, Size, [], Board),!.

%genListLists(+N, +Size, +OldBoard, -Board)
genListLists(Size, Size, Board, Board).
genListLists(N, Size, OldBoard, Board):-
       genList(0, Size, [], List),
       appendList(OldBoard, [List], NewBoard),
       N2 is N+1,
       genListLists(N2, Size, NewBoard, Board).

%genList(+N, +Size, +OldList, -List)
genList(Size, Size, List, List).
genList(N, Size, OldList, List):-
       Obs is random(5),
       genObstacle(Obs, Field),
       appendList(OldList, [Field], NewList),
       N2 is N+1,
       genList(N2, Size, NewList, List).

%genObstacle(+Obs, -Field)
genObstacle(0, 3).
genObstacle(_, 0).



%%%%%%%%%%%%%%%%%%%%%%%
%%%% VISUALIZATION %%%%
%%%%%%%%%%%%%%%%%%%%%%%

%drawBoard(+Board, +Size)
drawBoard(Board, Size):-
       DashNum is Size*2-1,
       nl, write('    '), drawLetters(65, Size),
       nl, write('     '), drawDashes(DashNum), nl,
       drawLines(1, Board),
       write('     '), drawDashes(DashNum), nl,
       write('    '), drawLetters(65, Size), nl, nl,!.

%drawDashes(+DashNum)
drawDashes(0).
drawDashes(DashNum):-
       write('-'),
       DashNewNum is DashNum-1,
       drawDashes(DashNewNum).

%drawLetters(+Char, +Size)
drawLetters(_, 0).
drawLetters(Char, Size):-
       write(' '), put_char(Char),
       NewSize is Size-1,
       NextChar is Char+1,
       drawLetters(NextChar, NewSize).

%drawLines(+N, +Board)
drawLines(_,[]).
drawLines(N, [Line|T]):-
       (N < 10 -> write(' '); write('')),
       write(N), write(' |'), drawLine(Line), write(' | '),
       write(N), nl,
       N2 is N+1,
       drawLines(N2, T).

%drawLine(+Line)
drawLine([]).
drawLine([Char|T]):-
       writeChar(Char),
       drawLine(T).

%writeChar(+Char)
writeChar(0):- write(' .').
writeChar(1):- write(' O').
writeChar(2):- write(' X').
writeChar(3):- write(' #').



%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% MOVE COMPUTATION %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%

%computeMove(+Level, +MoveList, -Move)
computeMove(1, MoveList, Move):-
       keysort(MoveList, MoveListSorted),
       reverse(MoveListSorted, MoveListReversed),
       MoveListReversed = [_-Move|_].
      
computeMove(2, MoveList, Move):-
       Level is random(2)*2 + 1,
       computeMove(Level, MoveList, Move).

computeMove(3, MoveList, Move):-
       keysort(MoveList, MoveListSorted),
       MoveListSorted = [_-Move|_].

%reverseAI(+AI, -ReversedAI)
reverseAI(0, 0).
reverseAI(1, 3).
reverseAI(2, 2).
reverseAI(3, 1).

%moveCount(+Board, +Player, -Count, +CurrentPiece)
moveCount(Board, Player, Count, CurrentPiece):-
       moveCountAuxY(Board, Board, 1, Player, Count, 0, CurrentPiece).

%moveCountAuxY(+Board, +BoardAux, +Y, +Player, -Count, +CountAux, +CurrentPiece)
moveCountAuxY(_, [], _, _, CountAux, CountAux, _).
moveCountAuxY(Board, [H|T], Y, Player, Count, CountAux, CurrentPiece):-
       moveCountAuxX(Board, H, 1, Y, Player, CountX, 0, CurrentPiece),
       Yn is Y+1,
       CountTemp is CountX+CountAux,
       moveCountAuxY(Board, T, Yn, Player, Count, CountTemp, CurrentPiece).

%moveCountAuxX(+Board, +BoardAux, +X, +Y, +Player, -CountX, +CountAux, +CurrentPiece)
moveCountAuxX(_, [], _, _, _, CountAux, CountAux, _).
moveCountAuxX(Board, [_|T], X, Y, Player, CountX, CountAux, CurrentPiece):-
       cons(X, Y, Move),
       Xn is X+1,
       (validMove(Board, Player, Move, CurrentPiece) ->
              CountTemp is CountAux+1,
              moveCountAuxX(Board, T, Xn, Y, Player, CountX, CountTemp, CurrentPiece);
              moveCountAuxX(Board, T, Xn, Y, Player, CountX, CountAux,  CurrentPiece)).

%moveList(+Board, +Player, -MoveList, +CurrentPiece)
moveList(Board, Player, MoveList, CurrentPiece):-
       moveListAuxY(Board, Board, 1, Player, [], MoveList, CurrentPiece).

%moveListAuxY(+Board, +BoardAux, +Y, +Player, +TempList, -MoveList, +CurrentPiece)
moveListAuxY(_, [], _, _, TempList, TempList, _).
moveListAuxY(Board, [H|T], Y, Player, TempList, MoveList, CurrentPiece):-
       moveListAuxX(Board, H, 1, Y, Player, TempList, AuxList, CurrentPiece),
       Yn is Y+1,
       moveListAuxY(Board, T, Yn, Player, AuxList, MoveList, CurrentPiece).

%moveListAuxX(+Board, +BoardAux, +X, +Y, +Player, +TempList, -MoveList, +CurrentPiece)
moveListAuxX(_, [], _, _, _, TempList, TempList, _).
moveListAuxX(Board, [_|T], X, Y, Player, TempList, MoveList, CurrentPiece):-
       cons(X, Y, Move),
       Xn is X+1,
       (validMove(Board, Player, Move, CurrentPiece) ->
              assignMove(CurrentPiece, Player, Move, Board, NewBoard),
              changePlayer(Player, NextPlayer),
              moveCount(NewBoard, NextPlayer, Count, 0),
              appendList(TempList, [Count-Move], NewList),
              moveListAuxX(Board, T, Xn, Y, Player, NewList , MoveList, CurrentPiece);
              moveListAuxX(Board, T, Xn, Y, Player, TempList, MoveList, CurrentPiece)).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% ASSIGNMENT OF A VALID MOVEMENT %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%validMove(+Board, +Player, +Move, +CurrentPiece)
validMove(Board, Player, Move, CurrentPiece):-
       changePlayer(Player, OtherPlayer),
       car(Move, X), cdr(Move, Y),
       boardMember(CurrentPiece, X, Y, Board),
       XnRight is X+1,      not(boardMember(OtherPlayer, XnRight, Y, Board)),
       XnLeft is X-1,       not(boardMember(OtherPlayer, XnLeft, Y, Board)),
       YnUp is Y+1,         not(boardMember(OtherPlayer, X, YnUp, Board)),
       YnDown is Y-1,       not(boardMember(OtherPlayer, X, YnDown, Board)),!.

%assignMove(+OldPiece, +NewPiece, +Move, +Board, -NewBoard)
assignMove(OldPiece, NewPiece, Move, Board, NewBoard):-
       car(Move, X), cdr(Move, Y),
       assignMoveAux(1, OldPiece, NewPiece, X, Y, Board, NewBoard),!.

%assignMoveAux(+Yn, +OldPiece, +NewPiece, +X, +Y, +Board, -NewBoard)
assignMoveAux(_, _, _, _, _, [], []).
assignMoveAux(Y, OldPiece, NewPiece, X, Y, [Line|T1], [NewLine|T2]):-
       changeLine(1, OldPiece, NewPiece, X, Line, NewLine),
       Yn is Y+1,
       assignMoveAux(Yn, OldPiece, NewPiece, X, Y, T1, T2).

assignMoveAux(Yn, OldPiece, NewPiece, X, Y, [Line|T1], [Line|T2]):-
       Yn \= Y, Ytemp is Yn+1,
       assignMoveAux(Ytemp, OldPiece, NewPiece, X, Y, T1, T2).

%changeLine(+Xn, +OldPiece, +NewPiece, +X, +Board, -NewBoard)
changeLine(_, _, _, _, [], []).
changeLine(X, OldPiece, NewPiece, X, [OldPiece|T1], [NewPiece|T2]):-
       Xn is X+1,
       changeLine(Xn, OldPiece, NewPiece, X, T1, T2).

changeLine(Xn, OldPiece, NewPiece, X, [H|T1], [H|T2]):-
       Xn \= X, Xtemp is Xn+1,
       changeLine(Xtemp, OldPiece, NewPiece, X, T1, T2).



%%%%%%%%%%%%%%%%%%%%%%%
%%%% SPECIAL MOVES %%%%
%%%%%%%%%%%%%%%%%%%%%%%

%specialMove(+Board, +Player, +Size, +NextTurn, +MoveList, +MoveCount)
specialMove(Board, 1, Size, NextTurn, _, _):-
       write('Cats special move! Remove a piece from the dogs.'), nl,
       moveList(Board, 0, MoveList, 2),
       player(1, PlayerType, AI),
       reverseAI(AI, ReversedAI),
       getMove(PlayerType, MoveList, Move, Size, ReversedAI),
       validMove(Board, 0, Move, 2),
       assignMove(2, 0, Move, Board, NewBoard),
       moveCount(NewBoard, 1, Count, 0),
       moveList(NewBoard, 1, NextMoveList, 0),
       (Count =:= 0 ->
              moveCount(NewBoard, 2, Count2, 0),
              write('No moves available!'), nl,
              (Count2 =:= 0 ->
                     endGame(NewBoard, Size), !;
                     play(NewBoard, 2, Size, NextTurn));
              drawBoard(NewBoard, Size),
              nl, writePlayer(1), write('� turn:'), nl,
              getMove(PlayerType, NextMoveList, NextMove, Size, AI),
              validMove(NewBoard, 1, NextMove, 0),
              assignMove(0, 1, NextMove, NewBoard, FinalBoard),
              play(FinalBoard, 2, Size, NextTurn)).

specialMove(Board, 2, Size, NextTurn, MoveList, MoveCount):-
       write('Dogs special move! You got an extra round.'), nl,
       (MoveCount =:= 0 ->
              moveCount(Board, 1, MoveCount2, 0),
              write('No moves available!'), nl,
              (MoveCount2 =:= 0 ->
                     endGame(Board, Size), !;
                     play(Board, 1, Size, NextTurn));
              player(2, PlayerType, AI),
              getMove(PlayerType, MoveList, Move, Size, AI),
              validMove(Board, 2, Move, 0),
              assignMove(0, 2, Move, Board, NewBoard),
              moveCount(NewBoard, 2, Count, 0),
              moveList(NewBoard, 2, NextMoveList, 0),
              drawBoard(NewBoard, Size),
              nl, writePlayer(2), write('� turn:'), nl,
              (Count =:= 0 ->
                     moveCount(NewBoard, 1, Count2, 0),
                     write('No moves available!'), nl,
                     (Count2 =:= 0 ->
                            endGame(NewBoard, Size), !;
                            play(NewBoard, 1, Size, NextTurn));
                     getMove(PlayerType, NextMoveList, NextMove, Size, AI),
                     validMove(NewBoard, 2, NextMove, 0),
                     assignMove(0, 2, NextMove, NewBoard, FinalBoard),
                     play(FinalBoard, 1, Size, NextTurn))).



%%%%%%%%%%%%%%%%%%%%%
%%%% PIECE COUNT %%%%
%%%%%%%%%%%%%%%%%%%%%

%countPieces(+Board, +Player, -Count)
countPieces(Board, Player, Count):-
       countPiecesY(Board, Player, 1, 0, Count), !.

%countPiecesY(+Board, +Player, +Y, +CountAux, -Count)
countPiecesY([], _, _, CountAux, CountAux).
countPiecesY([H|T], Player, Y, CountAux, Count):-
       countPiecesX(H, Player, 1, 0, CountX),
       CountTemp is CountAux+CountX,
       Yn is Y+1,
       countPiecesY(T, Player, Yn, CountTemp, Count).

%countPiecesY(+Line, +Player, +X, +CountAux, -Count)
countPiecesX([], _, _, CountAux, CountAux).
countPiecesX([H|T], H, X, CountAux, Count):-
       CountTemp is CountAux+1,
       Xn is X+1,
       countPiecesX(T, H, Xn, CountTemp, Count).
countPiecesX([_|T], Player, X, CountAux, Count):-
       Xn is X+1,
       countPiecesX(T, Player, Xn, CountAux, Count).
      


%%%%%%%%%%%%%%%%%%%%%%%%
%%%% LIST UTILITIES %%%%
%%%%%%%%%%%%%%%%%%%%%%%%

%boardMember(?Piece, +X, +Y, +Board)
boardMember(Piece, X, Y, Board):-
       searchList(Line, Y, Board),
       searchList(Piece, X, Line).

%searchList(?Member, +N, +List)
searchList(Member, N, List):-
       searchListAux(Member, 1, N, List).

%searchListAux(?Member, +Idx, +N, +List)
searchListAux(Member, N, N, [Member|_]).
searchListAux(Member, Idx, N, [_|T]):-
       IdxTemp is Idx+1,
       searchListAux(Member, IdxTemp, N, T).
        
%appendList(+List1, +List2, -Result)
appendList([],X,X).
appendList([H|T1],X,[H|T2]):-
       appendList(T1,X,T2).
      
%lengthList(+List, -Length)
lengthList(List, Length):-
       lengthListAux(List, Length, 0).

%lengthListAux(+List, -Length, +LengthAux)
lengthListAux([], LengthAux, LengthAux).
lengthListAux([_|T], Length, LengthAux):-
       LengthTemp is LengthAux+1,
       lengthListAux(T, Length, LengthTemp).

%cons(+X, +Y, -Pair)
cons(X, Y, [X|[Y]]).

%car(+Pair, -Car)
car([Car|_], Car).

%cdr(+Pair, -Cdr)
cdr([_|[Cdr|_]], Cdr).



%%%%%%%%%%%%%%%%%
%%%% SOCKETS %%%%
%%%%%%%%%%%%%%%%%

port(60009).

% Server %

server:-
       current_host(Host),
       server(Host).

server(Host):-
       port(Port),
       write('Hostname: '), write(Host), write('  Port: '), write(Port), nl,
       socket('AF_INET', Socket),
       write('Socket initialized'), nl,
       socket_bind(Socket, 'AF_INET'(Host,Port)),
       write('Socket binded sucessfully'), nl,
       socket_listen(Socket, 5),
       write('Handshaking...'), nl,
       socket_accept(Socket, _Client, Stream),
       write('Sucess!'), nl,
       server_loop(Stream),
       socket_close(Socket),
       write('Server exit'), nl.

server_loop(Stream):-
       repeat,
       read(Stream, ClientRequest),
       write('Received: '), write(ClientRequest), nl,
       server_input(ClientRequest, ServerReply),
       format(Stream, '~q.~n', [ServerReply]),
       write(Stream, ServerReply),
       write('Send: '), write(ServerReply), nl,
       flush_output(Stream),
       (ClientRequest == bye; ClientRequest == end_of_file), !.


server_input(initialize, ok):-
       begin, !.
server_input(execute(Move, Board), ok(NewBoard)):-
       validMove(Move, Board),
       assignMove(Move, Board, NewBoard), !.
server_input(calculate(AI, Player, Board), ok(Move, NewBoard)):-
       moveList(Board, Player, MoveList, 0),
       computeMove(AI, MoveList, Move),
       assignMove(Move, Board, NewBoard), !.
server_input(end(Board), ok):-
       endGame, !.
server_input(bye, ok):- !.
server_input(end_of_file, ok):- !.
server_input(_, invalid):- !.
