/*
 *      simpfind.c		TR1T3G7
 *      
 *      Copyright 2008 	João Cristóvão Xavier	<ei06116@fe.up.pt>
 * 						João Pedro Ribeiro		<ei06019@fe.up.pt>
 *      
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *      
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *      MA 02110-1301, USA.
 */

#include <dirent.h>
#include <fnmatch.h>
#include <getopt.h>
#include <limits.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#include <wait.h>
#include "auxiliar.h"
#include "sighandlers.h"

time_t currenttime;

int main(int argc, char* argv[])
{	
	// handling assign and information of the time at the moment the program is run
	currenttime = time(NULL);
	signal(SIGINT, siginthandler);
	signal(SIGQUIT, sigquithandler);
	
	// -name
	int nameflag = FALSE;
	char* name;
	
	// -type
	int typeflag = FALSE;
	int type;
	
	// -perm
	int permflag = FALSE;
	int perm;
	
	// -maxdepth
	int maxdepth = INT_MAX;
	
	// -mmin
	int mminflag = FALSE;
	int mminmode;
	int mminval;
	
	// flags: -print & -delete
	static int printflag = FALSE;
	static int deleteflag = FALSE;
	static int dummyflag = TRUE;
		
	// path resolution
	int barflag = FALSE;
	char cwd[PATH_MAX+1] = ".";
	
	// if argv[1] exists and begins with a '-', it's a command and not a path
	if (argc > 1 && argv[1][0] != '-')
	{	
		if (chdir(argv[1]) == -1) // invalid filename, chdir returns -1
		{
			fprintf(stderr, "%s: %s: No such file or directory\n", argv[0], argv[1]);
			exit(1);
		}
		else if (strcmp(argv[1], ".") != 0)	// to display '.' as cwd
			getcwd(cwd, PATH_MAX+1);		// to get the exact cwd path
		
		// barflag avoids display of a double bar when passing '/' in path
		if (strcmp(argv[1], "/") == 0)
			barflag = TRUE;
	}	
	
	// exec resolution
	int c = 0, index = 0, execflag = FALSE;
	char* execparam[argc];
	
	while (c != argc)
		if (strcmp(argv[c++], "-exec") == 0)
		{
			execflag = TRUE;
			argv[c-1] = "-dummy";	// switch the argv parameter parsed to a dummy flag so getopt doesn't evaluate -exec
			
			while (strcmp(argv[c], ";") != 0)
			{		
				execparam[index++] = argv[c];
				argv[c++] = "-dummy";
				
				if (argc == c)	// when the terminal sequence "\;" is not found
				{		
					fprintf(stderr, "%s: missing argument to 'exec-'\n", argv[0]);
					exit(1);
				}
			}
			
			execparam[index] = NULL;
			
			break;
		}

	static struct option long_options[] =
	{
		// flags
		{"dummy",	no_argument,		&dummyflag,		TRUE},
		{"print",	no_argument,		&printflag, 	TRUE},
		{"delete",  no_argument, 		&deleteflag,	TRUE},
		// conditions
		{"name",	required_argument,	0,	1},
		{"type",	required_argument,	0,	2},
		{"perm",  	required_argument, 	0,	3},
		{"maxdepth",required_argument,	0,	4},
		{"mmin",	required_argument,	0,	5},
		{0, 0, 0, 0}
	};
	
    while ((c = getopt_long_only(argc, argv, "", long_options, NULL)) != -1)
    {  
		switch (c)
		{
			case 0: // -print or -delete or -dummy
				break;
				
			case 1: // -name
				nameflag = TRUE;
				name = optarg;
				break;
	
			case 2: // -type
				if (strlen(optarg) > 1)
				{
					fprintf(stderr, "%s: invalid argument '%s' to '-type'\n", argv[0], optarg);
					exit(1);
				}
					
				char typetemp = optarg[0];
				typeflag = TRUE;
				
				switch(typetemp)
				{
					case 'f':
						type = S_IFREG;		// regular file
						break;
					case 'd':
						type = S_IFDIR;		// directory
						break;
					case 'l':
						type = S_IFLNK;		// symbolic link
						break;
					default:
						fprintf(stderr, "%s: invalid argument '%s' to '-type'\n", argv[0], optarg);
						exit(1);
				}
				break;
				
			case 3: // -perm
				perm = octaltodecimal(atoi(optarg));
				if (perm < 0 || !isnumber(optarg))
				{
					fprintf(stderr, "./simpfind: invalid mode '%s'\n", optarg);
					exit(1);
				}
				permflag = TRUE;
				break;
				
			case 4: // -maxdepth
				maxdepth = atoi(optarg);
				if (maxdepth < 0 || !isnumber(optarg))
				{
					fprintf(stderr, "%s: invalid argument '%s' to '-maxdepth'\n", argv[0], optarg);
					exit(1);
				}
				break;
				
			case 5: // -mmin
				mminval = atoi(optarg);
				if (!isnumber(optarg))
				{
					fprintf(stderr, "%s: invalid argument '%s' to '-mmin'\n", argv[0], optarg);
					exit(1);
				}
				
				mminval = (mminval < 0 ? -mminval : mminval); // to ensure a non-negative value
				mminflag = TRUE;
				
				switch (optarg[0])
				{
					case '+':
						mminmode = MORE;
						break;
					case '-':
						mminmode = LESS;
						break;
					default:
						mminmode = EQUAL;
				}
				break;

			case '?': // getopt handles the error message
				exit(1);

			default: abort(); // shouldn't get here
		}
	}

	int depth = 0;
	int permmask = octaltodecimal(777); // mask to retrieve the permissions (9 LSB)
	DIR* cdir;
	struct stat sb;
	struct dirent* cdirent;
	

	while (depth == 0 || cdirent != NULL)
	{	
		int showfile = TRUE;
		char* filename = "", filepath[NAME_MAX+1] = "";
		strcat(filepath, cwd);
		
		if (depth != 0)
		{
			filename = cdirent->d_name;
			
			// ignores the "." and ".." that appear on all directories
			if (strcmp(filename, ".") == 0 || strcmp(filename, "..") == 0)
			{
				cdirent = readdir(cdir);
				continue;
			}
			
			// appends a bar and the filename to the filepath
			strcat(filepath, "/");
			strcat(filepath, filename);
		}
		else
			filename = cwd;
		
		lstat(filepath, &sb); // retrieves information about the file
		
		if (
			(typeflag && ((sb.st_mode & S_IFMT) != type))				||
			(nameflag && fnmatch(name, filename, 0) != 0)				||
			(permflag && ((sb.st_mode & permmask) != perm))				||
			(mminflag && !istimeequal(sb.st_mtime, mminval, mminmode))	||
			(depth > maxdepth)
		   )
			showfile = FALSE;	
			
		if (showfile)
		{			
			if (printflag)
				printf("%s\n", filepath + sizeof(char)*barflag); // prevents the writing of a double bar if '/' is called on path
			
			if (execflag)
			{
				char* execparamtemp[index];
				
				for (c = 0; c != index; c++)
					execparamtemp[c] = strcmp(execparam[c], "{}") == 0 ? filepath : execparam[c]; // swaps all '{}' for the filepath
								
				execparamtemp[index] = NULL;
			
				switch (fork())
				{
					case 0:	// the child process will execute the function called in -exec
						if (execvp(execparamtemp[0], execparamtemp) == -1)
						{
							fprintf(stderr, "%s: %s: No such file or directory\n", argv[0], execparam[0]);
							exit(1);
						}	
						break;
					case -1:
						fprintf(stderr, "%s\n", "./simpfind: fork error");
						exit(1);
					default:	// the parent process will wait until the execution of the function is over to resume
						wait(NULL);
				}
			}
		
			if (deleteflag)
				if (remove(filepath) == -1)
					fprintf(stderr, "%s: cannot delete %s: Directory not empty\n", argv[0], filepath);	
		}
		
		if (S_ISDIR(sb.st_mode))	// analyses if the current file is a directory
			switch (fork())
			{
				case 0: // ignores SIGINT for children processes, opens a new directory and loops back
					signal(SIGINT, SIG_ IGN);
					depth++;
					strcpy(cwd, filepath);
					cdir = opendir(filepath);
					break;
				case -1:
 					fprintf(stderr, "%s\n", "./simpfind: fork error");
					exit(1);
				default: // parent process waiting for children to ensure a DFS (Depth-First Search)
					wait(NULL);
			}
		
		if (depth == 0)	// the father process breaks out from while after all its children having processed
			break;
			
		cdirent = readdir(cdir);
	}
	
	closedir(cdir);
	
	return 0;
}
