/*
 *      auxiliar.h		TR1T3G7
 *      
 *      Copyright 2008 	João Cristóvão Xavier	<ei06116@fe.up.pt>
 * 						João Pedro Ribeiro		<ei06019@fe.up.pt>
 *      
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *      
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *      MA 02110-1301, USA.
 */

#ifndef _AUXILIAR_H
#define _AUXILIAR_H

// boolean constants
#define TRUE	1
#define FALSE	0

// -mmin constants
#define MORE	0
#define LESS	1
#define EQUAL	2

// header of getline
ssize_t getline(char** line_ptr, size_t* n, FILE* stream);
	
// converts the octal var from octal mode to decimal mode
int octaltodecimal(int octal);
// returns 1 if the modified time is MORE/LESS than / EQUAL to mminval, 0 if not
int istimeequal(time_t modified, int mminval, int mminmode);
// returns 1 if str is a number, 0 if not
int isnumber(char* str);

#endif
