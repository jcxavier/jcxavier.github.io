/*
 *      auxiliar.c		TR1T3G7
 *      
 *      Copyright 2008 	João Cristóvão Xavier	<ei06116@fe.up.pt>
 * 						João Pedro Ribeiro		<ei06019@fe.up.pt>
 *      
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *      
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *      MA 02110-1301, USA.
 */

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "auxiliar.h"

extern time_t currenttime;

int octaltodecimal(int octal)
{
	int decimal = 0, digit, exp = 1, validation = FALSE;
        
	while(octal != 0)
	{
		digit = octal % 10;

		if(digit > 7) // if any digit is > 7, it's not a valid octal number
			validation = TRUE;
			
		octal /= 10;
		decimal += digit * exp;
		 
		exp *= 8;
	}
	
	if (!validation)
		return decimal;
	
	fprintf(stderr, "./simpfind: invalid mode '%d'\n", octal);
	exit(1);
}

int istimeequal(time_t modified, int mminval, int mminmode)
{
	int mins = difftime(currenttime, modified) / 60;
	
	return	((mminmode == MORE)  && (mins > mminval ))	||
			((mminmode == LESS)  && (mins < mminval ))	||
			((mminmode == EQUAL) && (mins == mminval));
}

int isnumber(char* str)
{
	// if the first position of the string is a '+' or '-', it might be a number too
	if (!isdigit(str[0]) && (str[0] != '+') && (str[0] != '-'))
		return FALSE;
	
	int i;
	for (i = 1; i != strlen(str); i++)
		if (!isdigit(str[i]))
			return FALSE;
			
	return TRUE;
}
