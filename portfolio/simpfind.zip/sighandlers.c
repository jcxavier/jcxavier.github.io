/*
 *      sighandlers.c	TR1T3G7
 *      
 *      Copyright 2008 	João Cristóvão Xavier	<ei06116@fe.up.pt>
 * 						João Pedro Ribeiro		<ei06019@fe.up.pt>
 *      
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *      
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *      MA 02110-1301, USA.
 */

#include <ctype.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "auxiliar.h"
#include "sighandlers.h"

void sigquithandler(int sig) { exit(0); }

void siginthandler(int sig)
{
	signal(SIGTTOU, SIG_IGN); // SIGTTOU (stop)
	killpg(0, SIGTTOU);
	
	char* userinput = "";
	size_t len = 0;
	
	putchar('\n');
	
	// getline saves the string with the '\n' character, so the size is 2 instead of 1
	while (strlen(userinput) != 2 && toupper(userinput[0]) != 'N')
	{
		printf("./simpfind: do you want to exit? (y/n): ");
		getline(&userinput, &len, stdin);
		
		if (strlen(userinput) == 2 && (toupper(userinput[0]) == 'Y' || toupper(userinput[0]) == 'S'))
			killpg(0, SIGQUIT); // calls sigquithandler to exit all processes
	}
	
	killpg(0, SIGCONT); // SIGCONT (resume)
}
