/*
 *      sighandlers.h	TR1T3G7
 *      
 *      Copyright 2008 	João Cristóvão Xavier	<ei06116@fe.up.pt>
 * 						João Pedro Ribeiro		<ei06019@fe.up.pt>
 *      
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *      
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *      MA 02110-1301, USA.
 */

#ifndef _SIGHANDLERS_H
#define _SIGHANDLERS_H

// SIGINT handler, called only by the parent process. Stops all children and
// asks the user if whether he wants to quit the program
void siginthandler(int sig);
// SIGQUIT handler for all processes, closes all processes with the exit code 0
void sigquithandler(int sig);

#endif
